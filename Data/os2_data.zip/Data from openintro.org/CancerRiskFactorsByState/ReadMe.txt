Main article
Fedewa SA, Sauer AG, Siegel RL, Jemal A. Prevalence of Major Risk Factors and Use of Screening Tests for Cancer in the United States. Cancer, Epidemiology, Biomarkers, & Prevention. April 2015, 24:637.


NPR article
http://www.npr.org/blogs/health/2015/04/17/398019555/the-state-of-the-cancer-nation
